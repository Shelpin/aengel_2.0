// Stub declarations file to prevent hard TS failures in downstream consumers
// This package's DTS generation is temporarily disabled (target: v4.2)
export * from '@elizaos/core/public-api'; 