import { Memory, MemoryData, MemoryQuery } from './types.js';
import { v4 as uuidv4 } from 'uuid';

/**
 * Fallback Memory Manager
 * 
 * This is a simple in-memory implementation of the Memory Manager
 * that can be used as a fallback when the real memory manager
 * is not available.
 */

// Define the options interface
interface MemoryOptions {
  limit?: number;
  type?: string;
  roomId?: string | null;
}

export class FallbackMemoryManager {
  private memories: Memory[] = [];
  private nextId = 1;
  private dbAdapter: any; // Adapter for SQLite operations
  private agentId: string;
  private logger: any; 
  private useSqlite: boolean = true; // Explicitly toggle SQLite use
  private dbInitialized: boolean = false;
  private lastSqliteError: Error | null = null;
  private consecutiveSqliteErrors: number = 0;
  private maxConsecutiveSqliteErrors: number = 3;
  private maxMemories: number = 1000;  // Maximum number of memories to keep in memory
  
  // Add connection pooling
  private connectionPool = {
    connections: [] as Array<{conn: any, inUse: boolean}>,
    maxSize: 5,
    getConnection() {
      for (let conn of this.connections) {
        if (!conn.inUse) {
          conn.inUse = true;
          return conn.conn;
        }
      }
      return null;
    },
    addConnection(conn: any) {
      if (this.connections.length < this.maxSize) {
        this.connections.push({ conn, inUse: true });
        return conn;
      }
      return null;
    },
    releaseConnection(conn: any) {
      for (let c of this.connections) {
        if (c.conn === conn) {
          c.inUse = false;
          break;
        }
      }
    }
  };

  constructor(agentId: string = 'unknown', dbAdapter?: any, logger?: any, useSqlite: boolean = true) {
    this.agentId = agentId;
    this.dbAdapter = dbAdapter;
    this.logger = logger || console;
    this.useSqlite = useSqlite;
    
    // VALHALLA FIX: Log info about the database adapter and SQLite usage
    if (dbAdapter && this.useSqlite) {
      this.logger.info(`[MEMORY] FallbackMemoryManager initialized with database adapter for agent ${agentId}. SQLite mode: ENABLED`, '', '');
      // Add the adapter to the connection pool
      this.connectionPool.addConnection(dbAdapter);
    } else if (dbAdapter && !this.useSqlite) {
      this.logger.info(`[MEMORY] FallbackMemoryManager initialized with database adapter for agent ${agentId}, but SQLite is DISABLED by configuration. Using in-memory storage.`, '', '');
      this.dbAdapter = null; // Force in-memory mode if SQLite is disabled
    } else {
      this.logger.warn(`[MEMORY] FallbackMemoryManager initialized WITHOUT database adapter for agent ${agentId}, will use in-memory storage`, '', '');
    }
    
    // Initialize schema if adapter is available
    if (this.dbAdapter && this.useSqlite) {
      this.logger.info(`[MEMORY] Initializing SQLite schema for agent ${agentId}`, '', '');
      this.initializeSchema().catch(err => {
        this.logger.error(`[MEMORY] Failed to initialize schema: ${err.message || err}`, '', '');
        this.logger.error(`[MEMORY] Stack trace: ${err.stack || 'No stack trace available'}`, '', '');
      });
    } else {
      this.logger.info(`[MEMORY] SQLite fallback: ${this.useSqlite ? 'ON' : 'OFF'}`, '', '');
    }

    // Automatically test SQLite connection if adapter is provided
    if (this.dbAdapter) {
      this.testSqliteConnection().then(result => {
        this.logger.info(`[MEMORY] SQLite connectivity test ${result ? 'passed' : 'failed'}`, '', '');
      }).catch(error => {
        this.logger.error(`[MEMORY] Error testing SQLite connectivity: ${error.message}`, '', '');
        this.useSqlite = false;
      });
    }
  }
  
  // VALHALLA FIX: Add public getter for useSqlite
  getUseSqlite(): boolean {
    return this.useSqlite;
  }

  /**
   * Initialize the database schema
   */
  private async initializeSchema(): Promise<boolean> {
    if (!this.dbAdapter || !this.useSqlite) {
      return false;
    }
    
    if (this.dbInitialized) {
      return true;
    }
    
    // VALHALLA FIX: Add retry mechanism for schema initialization
    const maxRetries = 3;
    let retryCount = 0;
    let lastError = null;
    
    while (retryCount < maxRetries) {
      try {
        this.logger.debug(`[MEMORY] Initializing SQLite schema (attempt ${retryCount + 1}/${maxRetries})`, '', '');
        
        // VALHALLA FIX: Forcefully close and reset the connection if we're retrying
        if (retryCount > 0) {
          this.logger.warn(`[MEMORY] Retry attempt ${retryCount + 1}: Resetting SQLite connection`, '', '');
          try {
            await this.dbAdapter.close();
          } catch (closeErr) {
            this.logger.warn(`[MEMORY] Error closing adapter: ${closeErr.message}`, '', '');
            // Continue anyway
          }
        }
        
        // VALHALLA FIX: Try to drop the table completely if this is a retry
        // Wrapped in proper error handling to avoid database lockup
        if (retryCount > 0) {
          try {
            this.logger.warn(`[MEMORY] Checking if memories table exists before dropping`, '', '');
            const tableCheck = await this.dbAdapter.query(`SELECT name FROM sqlite_master WHERE type='table' AND name='memories'`);
            
            if (tableCheck && tableCheck.length > 0) {
              this.logger.warn(`[MEMORY] Forcefully dropping memories table to recreate it`, '', '');
              try {
                await this.dbAdapter.execute(`DROP TABLE IF EXISTS memories`);
                this.logger.info(`[MEMORY] Successfully dropped memories table`, '', '');
              } catch (dropErr) {
                this.logger.warn(`[MEMORY] Could not drop table: ${dropErr.message}`, '', '');
                // Wait a moment before continuing to allow any locks to clear
                await new Promise(resolve => setTimeout(resolve, 1000));
              }
            } else {
              this.logger.info(`[MEMORY] No existing memories table found, skipping drop operation`, '', '');
            }
          } catch (checkErr) {
            this.logger.warn(`[MEMORY] Error checking table existence: ${checkErr.message}`, '', '');
            // Continue anyway
          }
        }
        
        // VALHALLA FIX: Improved schema with explicit type column definition
        // Create memories table if it doesn't exist
        const createMemoriesTable = `
          CREATE TABLE IF NOT EXISTS memories (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL DEFAULT 'message',
            agent_id TEXT NOT NULL,
            user_id TEXT,
            timestamp INTEGER,
            content TEXT NOT NULL
          )
        `;
        
        await this.dbAdapter.execute(createMemoriesTable);
        
        // Check if the table was actually created
        const checkTable = await this.dbAdapter.query(`SELECT name FROM sqlite_master WHERE type='table' AND name='memories'`);
        if (!checkTable || checkTable.length === 0) {
          throw new Error("Table creation didn't succeed - table not found in sqlite_master");
        }
        
        // Verify the schema to ensure type column exists
        try {
          const tableInfo = await this.dbAdapter.query(`PRAGMA table_info(memories)`);
          const typeColumn = tableInfo.find(col => col.name === 'type');
          
          if (!typeColumn) {
            this.logger.warn(`[MEMORY] 'type' column not found in memories table, attempting to add it`, '', '');
            await this.dbAdapter.execute(`ALTER TABLE memories ADD COLUMN type TEXT NOT NULL DEFAULT 'message'`);
            this.logger.info(`[MEMORY] Successfully added 'type' column to memories table`, '', '');
          } else {
            this.logger.info(`[MEMORY] 'type' column exists in memories table`, '', '');
          }
        } catch (schemaErr) {
          this.logger.error(`[MEMORY] Error checking schema: ${schemaErr.message}`, '', '');
          // Continue anyway, we'll handle errors during insertions
        }
        
        // Create indexes
        const createTypeIndex = `CREATE INDEX IF NOT EXISTS idx_memories_type ON memories (type)`;
        await this.dbAdapter.execute(createTypeIndex);
        
        const createAgentIndex = `CREATE INDEX IF NOT EXISTS idx_memories_agent ON memories (agent_id)`;
        await this.dbAdapter.execute(createAgentIndex);
        
        const createTimestampIndex = `CREATE INDEX IF NOT EXISTS idx_memories_timestamp ON memories (timestamp DESC)`;
        await this.dbAdapter.execute(createTimestampIndex);
        
        // Verify we can do a basic query on the table
        await this.dbAdapter.query('SELECT COUNT(*) FROM memories');
        
        this.logger.info('[MEMORY] SQLite schema initialized successfully', '', '');
        this.dbInitialized = true;
        
        // Reset error counter on successful initialization
        this.consecutiveSqliteErrors = 0;
        
        return true;
      } catch (error) {
        lastError = error;
        retryCount++;
        this.logger.error(`[MEMORY] Schema initialization attempt ${retryCount} failed: ${error.message}`, '', '');
        
        if (retryCount < maxRetries) {
          // Wait before retrying (exponential backoff)
          const waitTime = Math.pow(2, retryCount) * 500; // 1s, 2s, 4s
          this.logger.warn(`[MEMORY] Waiting ${waitTime}ms before retry...`, '', '');
          await new Promise(resolve => setTimeout(resolve, waitTime));
        }
      }
    }
    
    // All retries failed
    this.handleSqliteError('schema initialization', lastError);
    
    // VALHALLA FIX: Force in-memory mode if schema initialization fails
    this.logger.warn('⚠️ [MEMORY] SQLite adapter failed schema check after multiple retries, forcing in-memory mode');
    this.dbAdapter = null;
    this.useSqlite = false;
    
    return false;
  }

  /**
   * Create a memory entry for a message
   * @param memoryData The memory data object
   * @returns The created memory, if successful
   */
  async createMemory(memoryData: MemoryData): Promise<MemoryData | null> {
    try {
      // Extract the content from the memoryData structure
      const { content, roomId, userId, type } = memoryData;
      const contentText = content?.text || '';
      const memoryId = uuidv4();
      
      this.logger.info(`[MEMORY] Creating Memory ${memoryId} ${contentText.substring(0, 50)}...`, '', '');
      
      // Create a complete memory object with any missing fields filled in
      const completeMemory: MemoryData = {
        id: memoryId,
        roomId: roomId || ('telegram-' + this.agentId),
        userId: userId || 'user',
        type: type || 'message',
        content: content || { text: '' }
      };
      
      // Also store in our in-memory array as backup in all cases
      this.memories.push({
        id: memoryId,
        type: completeMemory.type || 'message',
        content: completeMemory.content,
        userId: completeMemory.userId,
        roomId: completeMemory.roomId,
        createdAt: new Date()
      });

      // VALHALLA FIX: Skip database operation entirely if adapter is null
      if (!this.dbAdapter) {
        // Skip DB attempt entirely
        this.logger.info(`[MEMORY] Saving memory in-memory only`);
        return completeMemory;
      }

      // Create a memory in the database if adapter is available and SQLite is enabled
      if (this.dbAdapter && this.useSqlite) {
        try {
          // Ensure the table exists
          await this.initializeSchema();
          
          const timestamp = Date.now();
          
          // Try to insert memory into database
          try {
            const insertSql = `INSERT INTO memories (id, type, agent_id, user_id, timestamp, content)
                 VALUES (?, ?, ?, ?, ?, ?)`;
            const insertParams = [
              memoryId, 
              completeMemory.type || 'message', 
              this.agentId,
              completeMemory.userId,
              timestamp, 
              JSON.stringify(completeMemory.content)  // Store content as JSON string
            ];
            
            this.logger.debug(`[MEMORY] Executing SQL: ${insertSql} with params: ${JSON.stringify(insertParams)}`, '', '');
            
            await this.dbAdapter.execute(insertSql, insertParams);
            
            this.logger.info(`[MEMORY] Successfully stored memory ${memoryId} in SQLite`, '', '');
            
            // Verify memory was saved
            try {
              const verifySql = `SELECT * FROM memories WHERE id = ?`;
              this.logger.debug(`[MEMORY] Verifying memory storage with SQL: ${verifySql} and id: ${memoryId}`, '', '');
              const verifyResult = await this.dbAdapter.query(verifySql, [memoryId]);
              
              if (verifyResult && verifyResult.length > 0) {
                this.logger.info(`[MEMORY] Memory verification successful. Memory exists in database.`, '', '');
              } else {
                this.logger.warn(`[MEMORY] Memory verification failed. Memory not found in database after insert.`, '', '');
              }
            } catch (verifyError) {
              this.logger.error(`[MEMORY] Memory verification error: ${verifyError.message || JSON.stringify(verifyError)}`, '', '');
            }
          } catch (insertError) {
            // Log insert error but continue with in-memory storage
            this.logger.error(`[MEMORY] SQLite error inserting memory: ${insertError.message || JSON.stringify(insertError)}`, '', '');
            this.logger.error(`[MEMORY] Insert error stack trace: ${insertError.stack || 'No stack trace available'}`, '', '');
            this.logger.error(`[MEMORY] Insert error code: ${insertError.code || 'Unknown'}`, '', '');
            this.logger.warn('[MEMORY] Using in-memory fallback due to insert error', '', '');
          }
        } catch (error) {
          // VALHALLA FIX: Enhanced error logging with full details
          this.logger.error(`[MEMORY] SQLite error creating memory: ${error.message || error}`, '', '');
          if (error.code) {
            this.logger.error(`[MEMORY] SQLite error code: ${error.code}`, '', '');
          }
          if (error.stack) {
            this.logger.error(`[MEMORY] Stack trace: ${error.stack}`, '', '');
          }
          
          this.logger.warn('[MEMORY] Continuing with in-memory storage due to database error', '', '');
        }
      } else {
        this.logger.info('[MEMORY] Using virtual memory (SQLite adapter not available or disabled)', '', '');
      }
      
      // Always return the memory data regardless of SQLite success
      return completeMemory;
    } catch (error) {
      this.logger.error(`[MEMORY] Unexpected error creating memory: ${error.message || error}`, '', '');
      this.logger.error(`[MEMORY] Error stack trace: ${error.stack || 'No stack trace available'}`, '', '');
      // Return a basic memory even in case of error to prevent null returns
      return {
        id: uuidv4(),
        roomId: 'telegram-' + this.agentId,
        userId: 'user',
        type: 'message',
        content: {
          text: 'Error retrieving message content'
        }
      };
    }
  }

  async searchMemories(query: MemoryQuery, limit: number = 5): Promise<Memory[]> {
    // First try to use database if adapter is available and SQLite is enabled
    if (this.dbAdapter && this.useSqlite) {
      try {
        const searchSql = `SELECT * FROM memories WHERE agent_id = ? ORDER BY timestamp DESC LIMIT ?`;
        const searchParams = [this.agentId, limit];
        
        this.logger.debug(`[MEMORY] Searching memories with SQL: ${searchSql} and params: ${JSON.stringify(searchParams)}`, '', '');
        
        // Get connection from pool
        let conn = this.connectionPool.getConnection();
        if (!conn) {
          conn = this.connectionPool.addConnection(this.dbAdapter);
        }
        
        try {
          const result = await conn.query(searchSql, searchParams);
          // Release connection back to pool
          this.connectionPool.releaseConnection(conn);
          
          if (result && result.length > 0) {
            this.logger.info(`[MEMORY] Found ${result.length} memories in database`, '', '');
            return result.map(row => ({
              id: row.id,
              type: row.type,
              content: this.parseContent(row.content),
              userId: row.user_id,
              roomId: row.roomId || ('telegram-' + this.agentId),
              createdAt: new Date(row.timestamp)
            }));
          } else {
            this.logger.info(`[MEMORY] No memories found in database, falling back to in-memory search`, '', '');
          }
        } catch (error) {
          // Always release connection on error
          this.connectionPool.releaseConnection(conn);
          throw error;
        }
      } catch (error) {
        this.logger.error(`[MEMORY] Error searching memories in database: ${error.message}`, '', '');
        this.logger.error(`[MEMORY] Search error stack trace: ${error.stack || 'No stack trace available'}`, '', '');
        this.logger.warn('[MEMORY] Falling back to in-memory search', '', '');
        // Fall back to in-memory implementation
      }
    } else {
      this.logger.info(`[MEMORY] Using in-memory search (SQLite ${this.dbAdapter ? 'disabled' : 'not available'})`, '', '');
    }
    
    // In the fallback implementation, we just return the most recent memories
    return this.memories.slice(0, limit);
  }

  async saveMemory(memory: Memory): Promise<void> {
    // Assign a unique ID to the memory if not already present
    if (!memory.id) {
      memory.id = `mem_${this.nextId++}`;
    }
    
    // Always save to in-memory store regardless of SQLite
    this.memories.push({
      ...memory,
      createdAt: memory.createdAt || new Date()
    });
    
    // Try to save to database if adapter is available and SQLite is enabled
    if (this.dbAdapter && this.useSqlite) {
      try {
        const saveSql = `INSERT INTO memories (id, type, agent_id, user_id, content, timestamp) 
         VALUES (?, ?, ?, ?, ?, ?)`;
        const saveParams = [
          memory.id, 
          memory.type || 'message', 
          this.agentId,
          memory.userId || 'user',
          typeof memory.content === 'object' ? JSON.stringify(memory.content) : memory.content,
          memory.createdAt ? memory.createdAt.getTime() : Date.now()
        ];
        
        this.logger.debug(`[MEMORY] Saving memory with SQL: ${saveSql} and params: ${JSON.stringify(saveParams)}`, '', '');
        
        // Get connection from pool
        let conn = this.connectionPool.getConnection();
        if (!conn) {
          conn = this.connectionPool.addConnection(this.dbAdapter);
        }
        
        try {
          await conn.execute(saveSql, saveParams);
          // Release connection back to pool
          this.connectionPool.releaseConnection(conn);
          
          this.logger.info(`[MEMORY] Successfully saved memory ${memory.id} to SQLite`, '', '');
        } catch (error) {
          // Always release connection on error
          this.connectionPool.releaseConnection(conn);
          throw error;
        }
      } catch (error) {
        this.logger.error(`[MEMORY] Error saving memory to database: ${error.message}`, '', '');
        this.logger.error(`[MEMORY] Save error stack trace: ${error.stack || 'No stack trace available'}`, '', '');
        this.logger.warn('[MEMORY] Memory saved to in-memory store only', '', '');
      }
    } else {
      this.logger.info('[MEMORY] Memory saved to in-memory store only (SQLite not available or disabled)', '', '');
    }
  }

  /**
   * Test the SQLite connectivity and schema
   * @returns True if SQLite is working properly, false otherwise
   */
  async testSqliteConnection(): Promise<boolean> {
    try {
      // Reset to defaults
      this.lastSqliteError = null;
      this.consecutiveSqliteErrors = 0;
      
      // Check if we have an adapter
      if (!this.dbAdapter) {
        this.logger.warn('[MEMORY] No SQLite adapter available', '', '');
        this.useSqlite = false;
        return false;
      }

      // Try to execute a simple query to test connectivity
      this.logger.info('[MEMORY] Testing SQLite connectivity...', '', '');
      
      // Step 1: Ensure schema exists
      await this.initializeSchema();
      
      // Step 2: Try to insert a test record
      const testId = `test-${Date.now()}`;
      const testTimestamp = Date.now();
      
      try {
        const insertSql = `INSERT INTO memories (id, type, agent_id, user_id, timestamp, content)
            VALUES (?, ?, ?, ?, ?, ?)`;
        
        await this.dbAdapter.execute(insertSql, [
          testId,
          'test',
          this.agentId,
          'test_user',
          testTimestamp,
          JSON.stringify({ text: 'SQLite connectivity test' })
        ]);
        
        this.logger.info('[MEMORY] Successfully inserted test record', '', '');
        
        // Step 3: Try to read the test record
        const selectSql = `SELECT * FROM memories WHERE id = ?`;
        const result = await this.dbAdapter.query(selectSql, [testId]);
        
        if (result && result.length > 0) {
          this.logger.info('[MEMORY] Successfully read test record', '', '');
          
          // Step 4: Delete the test record
          const deleteSql = `DELETE FROM memories WHERE id = ?`;
          await this.dbAdapter.execute(deleteSql, [testId]);
          
          this.logger.info('[MEMORY] SQLite test completed successfully', '', '');
          this.useSqlite = true;
          this.dbInitialized = true;
          return true;
        } else {
          this.logger.error('[MEMORY] Failed to read test record', '', '');
          this.useSqlite = false;
          return false;
        }
      } catch (error) {
        this.logger.error(`[MEMORY] SQLite test failed: ${error.message}`, '', '');
        if (error.stack) {
          this.logger.error(`[MEMORY] Stack trace: ${error.stack}`, '', '');
        }
        this.lastSqliteError = error;
        this.useSqlite = false;
        return false;
      }
    } catch (error) {
      this.logger.error(`[MEMORY] SQLite connectivity test failed: ${error.message}`, '', '');
      if (error.stack) {
        this.logger.error(`[MEMORY] Stack trace: ${error.stack}`, '', '');
      }
      this.lastSqliteError = error;
      this.useSqlite = false;
      return false;
    }
  }

  /**
   * Helper to safely parse content stored as a string
   */
  private parseContent(content: string | any): any {
    if (typeof content !== 'string') {
      return content;
    }
    
    try {
      return JSON.parse(content);
    } catch (e) {
      // If parsing fails, return as-is in a text property
      return { text: content };
    }
  }

  /**
   * Get memories from storage
   */
  async getMemories(options: MemoryOptions = {}): Promise<Memory[]> {
    // Default options
    const limit = options.limit || 50;
    const type = options.type || 'chat';
    const roomId = options.roomId || null;
    
    // If SQLite is disabled or adapter is not available, use in-memory only
    if (!this.dbAdapter || !this.useSqlite) {
      this.logger.debug('[MEMORY] Using in-memory storage only for getMemories', '', '');
      return this.getInMemoryMemories(options);
    }
    
    try {
      // Ensure schema is initialized
      await this.initializeSchema();
      
      let sql = `
        SELECT * FROM memories 
        WHERE agent_id = ? AND type = ?
      `;
      
      const params: any[] = [this.agentId, type];
      
      // Add roomId filter if provided
      if (roomId) {
        sql += ` AND json_extract(content, '$.roomId') = ?`;
        params.push(roomId);
      }
      
      // Add limit and order
      sql += ` ORDER BY timestamp DESC LIMIT ?`;
      params.push(limit);
      
      this.logger.debug(`[MEMORY] Executing SQL: ${sql} with params: ${JSON.stringify(params)}`, '', '');
      
      const results = await this.dbAdapter.query(sql, params);
      
      if (!results || results.length === 0) {
        this.logger.debug('[MEMORY] No memories found in SQLite, falling back to in-memory', '', '');
        return this.getInMemoryMemories(options);
      }
      
      // Reset consecutive error counter on success
      if (this.consecutiveSqliteErrors > 0) {
        this.logger.info('[MEMORY] Successfully retrieved memories from SQLite after previous errors, resetting error counter', '', '');
        this.consecutiveSqliteErrors = 0;
      }
      
      // Parse the results
      const memories = results.map((row: any) => {
        try {
          const contentObj = JSON.parse(row.content);
          
          // Create a properly formatted Memory object from the database result
          const memory: Memory = {
            id: row.id,
            roomId: contentObj.roomId || '',
            userId: row.user_id || 'unknown',
            type: row.type || 'chat',
            createdAt: new Date(row.timestamp),
            content: {
              text: contentObj.text || '',
              metadata: contentObj.metadata || {}
            }
          };
          
          return memory;
        } catch (parseError) {
          this.logger.error(`[MEMORY] Error parsing memory content: ${parseError.message}`, '', '');
          return null;
        }
      }).filter(Boolean);
      
      this.logger.debug(`[MEMORY] Retrieved ${memories.length} memories from SQLite`, '', '');
      
      return memories;
    } catch (error) {
      this.handleSqliteError('getMemories', error);
      this.logger.info('[MEMORY] Falling back to in-memory storage for getMemories', '', '');
      return this.getInMemoryMemories(options);
    }
  }

  /**
   * Get memories from in-memory storage
   * @private
   */
  private getInMemoryMemories(options: MemoryOptions = {}): Memory[] {
    const limit = options.limit || 50;
    const type = options.type || 'chat';
    const roomId = options.roomId || null;
    
    let filteredMemories = this.memories.filter(mem => {
      let match = mem.type === type;
      
      // Apply roomId filter if provided
      if (match && roomId !== null) {
        match = mem.roomId === roomId;
      }
      
      return match;
    });
    
    // Sort by timestamp descending
    filteredMemories.sort((a, b) => {
      const dateA = a.createdAt instanceof Date ? a.createdAt.getTime() : 0;
      const dateB = b.createdAt instanceof Date ? b.createdAt.getTime() : 0;
      return dateB - dateA;
    });
    
    // Apply limit
    if (filteredMemories.length > limit) {
      filteredMemories = filteredMemories.slice(0, limit);
    }
    
    this.logger.debug(`[MEMORY] Retrieved ${filteredMemories.length} memories from in-memory storage`, '', '');
    
    return filteredMemories;
  }

  // Add a helper method to handle SQLite errors
  private handleSqliteError(operation: string, error: any): void {
    this.lastSqliteError = error;
    this.consecutiveSqliteErrors++;
    
    this.logger.error(`[MEMORY] SQLite error during ${operation}: ${error.message}`, '', '');
    
    if (error.code) {
      this.logger.error(`[MEMORY] SQLite error code: ${error.code}`, '', '');
    }
    
    if (error.stack) {
      this.logger.error(`[MEMORY] Stack trace: ${error.stack}`, '', '');
    }
    
    // Disable SQLite after too many consecutive errors
    if (this.consecutiveSqliteErrors >= this.maxConsecutiveSqliteErrors) {
      this.logger.warn(`[MEMORY] Too many consecutive SQLite errors (${this.consecutiveSqliteErrors}), disabling SQLite`, '', '');
      this.useSqlite = false;
    }
  }

  /**
   * Add a memory to storage
   */
  async addMemory(memory: any): Promise<void> {
    // VALHALLA FIX: Add logging for memory operations
    this.logger.info(`[MEMORY] Inserting memory with content: ${JSON.stringify(memory)}`, '', '');
    
    // Always store in-memory as fallback
    if (!memory.createdAt) {
      memory.createdAt = new Date();
    }
    
    // Create a properly formatted Memory object
    const memoryObj: Memory = {
      id: memory.id || `memory-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      roomId: memory.roomId || '',
      userId: memory.from?.id || 'unknown',
      type: memory.type || 'chat',
      createdAt: memory.createdAt || new Date(),
      content: {
        text: memory.text || '',
        metadata: memory.metadata || {}
      }
    };
    
    this.memories.push(memoryObj);
    
    // Limit in-memory size
    if (this.memories.length > this.maxMemories) {
      this.memories = this.memories.slice(-this.maxMemories);
    }
    
    // If SQLite is disabled or adapter is not available, only use in-memory
    if (!this.dbAdapter || !this.useSqlite) {
      return;
    }
    
    try {
      // Ensure the schema exists
      await this.initializeSchema();
      
      // Use roomId for memory.roomId if available
      const roomId = memoryObj.roomId || '';
      
      // Insert into SQLite
      const sql = `
        INSERT INTO memories (id, type, agent_id, user_id, timestamp, content)
        VALUES (?, ?, ?, ?, ?, ?)
      `;
      
      const timestamp = memoryObj.createdAt ? memoryObj.createdAt.getTime() : Date.now();
      
      const params = [
        memoryObj.id,
        memoryObj.type || 'chat',
        this.agentId,
        memoryObj.userId || '',
        timestamp,
        JSON.stringify({
          text: memoryObj.content.text,
          roomId: roomId,
          metadata: memoryObj.content.metadata || {}
        })
      ];
      
      await this.dbAdapter.execute(sql, params);
      
      // Reset consecutive error counter on success
      if (this.consecutiveSqliteErrors > 0) {
        this.logger.info('[MEMORY] Successfully added memory to SQLite after previous errors, resetting error counter', '', '');
        this.consecutiveSqliteErrors = 0;
      }
      
      this.logger.debug(`[MEMORY] Added memory to SQLite: ${memoryObj.id}`, '', '');
    } catch (error) {
      this.handleSqliteError('addMemory', error);
      this.logger.info('[MEMORY] Memory still saved to in-memory fallback', '', '');
    }
  }
} 