export declare const elizaLogger: import("pino").Logger<string, boolean>;
export default elizaLogger;
