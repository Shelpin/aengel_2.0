console.log('Trying to emit declarations...');
