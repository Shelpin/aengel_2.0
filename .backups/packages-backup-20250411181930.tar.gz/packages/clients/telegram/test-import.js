"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const public_api_1 = require("@elizaos/core/public-api");
console.log(typeof public_api_1.Memory);
