import { Memory } from "@elizaos/core/public-api"; console.log(typeof Memory);
